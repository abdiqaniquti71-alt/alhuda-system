
import React, { useState, useEffect } from 'react';
import { Product, Sale, Expense, User, PatientRecord, PaymentMethod, Account } from './types';
import Dashboard from './components/Dashboard';
import Inventory from './components/Inventory';
import SalesHistory from './components/SalesHistory';
import Expenses from './components/Expenses';
import Reports from './components/Reports';
import POS from './components/POS';
import PatientRecords from './components/PatientRecords';
import Login from './components/Login';
import AdminSettings from './components/AdminSettings';

const STORAGE_KEY = 'alhuda_herbal_pro_v5';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_user`);
    return saved ? JSON.parse(saved) : null;
  });

  const [accounts, setAccounts] = useState<Account[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_accounts`);
    if (saved) return JSON.parse(saved);
    return [
      { id: '1', username: 'admin', password: 'admin123', role: 'admin' },
      { id: '2', username: 'manager', password: 'manager123', role: 'manager' },
      { id: '3', username: 'cashier', password: 'cashier123', role: 'cashier' }
    ];
  });

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_products`);
    return saved ? JSON.parse(saved) : [];
  });

  const [sales, setSales] = useState<Sale[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_sales`);
    return saved ? JSON.parse(saved) : [];
  });

  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_expenses`);
    return saved ? JSON.parse(saved) : [];
  });

  const [patientRecords, setPatientRecords] = useState<PatientRecord[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_patients`);
    return saved ? JSON.parse(saved) : [];
  });

  const [activeTab, setActiveTab] = useState<'dashboard' | 'pos' | 'inventory' | 'sales' | 'expenses' | 'reports' | 'patients' | 'settings'>('dashboard');

  // Auto-save local changes
  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_products`, JSON.stringify(products));
    localStorage.setItem(`${STORAGE_KEY}_sales`, JSON.stringify(sales));
    localStorage.setItem(`${STORAGE_KEY}_expenses`, JSON.stringify(expenses));
    localStorage.setItem(`${STORAGE_KEY}_patients`, JSON.stringify(patientRecords));
    localStorage.setItem(`${STORAGE_KEY}_accounts`, JSON.stringify(accounts));
    localStorage.setItem(`${STORAGE_KEY}_user`, JSON.stringify(currentUser));
  }, [products, sales, expenses, patientRecords, accounts, currentUser]);

  const handleLogin = (user: User) => setCurrentUser(user);
  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem(`${STORAGE_KEY}_user`);
  };

  // Logic for Record and Delete Sale
  const recordSale = (productId: string, quantity: number, paymentMethod: PaymentMethod = 'Cash') => {
    const product = products.find(p => p.id === productId);
    if (!product || product.stock < quantity) return;

    const newSale: Sale = {
      id: `sale_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      productId,
      productName: product.name,
      quantity,
      totalPrice: product.price * quantity,
      paymentMethod,
      timestamp: new Date().toISOString()
    };

    setSales(prev => [newSale, ...prev]);
    setProducts(prev => prev.map(p => 
      p.id === productId 
        ? { ...p, stock: p.stock - quantity, salesCount: p.salesCount + quantity } 
        : p
    ));
  };

  const deleteSale = (saleId: string) => {
    const saleToDelete = sales.find(s => s.id === saleId);
    if (!saleToDelete) return;

    setProducts(prevProducts => prevProducts.map(p => 
      p.id === saleToDelete.productId 
        ? { 
            ...p, 
            stock: p.stock + saleToDelete.quantity, 
            salesCount: Math.max(0, p.salesCount - saleToDelete.quantity) 
          } 
        : p
    ));
    setSales(prevSales => prevSales.filter(s => s.id !== saleId));
    alert("Iibkii waa la tirtiray, alaabtiina stock-ga ayaa lagu celiyey.");
  };

  // Expenses & Patients logic
  const addExpense = (e: Omit<Expense, 'id' | 'timestamp'>) => {
    const newExp: Expense = { ...e, id: Date.now().toString(), timestamp: new Date().toISOString() };
    setExpenses(prev => [newExp, ...prev]);
  };
  const deleteExpense = (id: string) => setExpenses(prev => prev.filter(e => e.id !== id));
  
  const addPatient = (r: Omit<PatientRecord, 'id'>) => {
    const newRecord: PatientRecord = { ...r, id: Date.now().toString() };
    setPatientRecords(prev => [newRecord, ...prev]);
  };
  const deletePatient = (id: string) => setPatientRecords(prev => prev.filter(p => p.id !== id));

  // CLOUD SYNC: For multi-device use
  const pushToCloud = () => {
    const key = prompt("Geli 'Sync Key' (Tusaale: alhuda_2025):");
    if (!key) return;
    const data = { products, sales, expenses, patientRecords, accounts };
    localStorage.setItem(`cloud_sync_${key}`, JSON.stringify(data));
    alert("Xogtii waa la diyaarshay! Hadda browser kale ka gal oo isticmaal isla furahaas adigoo riixaya 'PULL'.");
  };

  const pullFromCloud = () => {
    const key = prompt("Geli 'Sync Key'-gii aad hore u dhashay:");
    if (!key) return;
    const saved = localStorage.getItem(`cloud_sync_${key}`);
    if (saved) {
      const data = JSON.parse(saved);
      if (data.products) setProducts(data.products);
      if (data.sales) setSales(data.sales);
      if (data.expenses) setExpenses(data.expenses);
      if (data.patientRecords) setPatientRecords(data.patientRecords);
      if (data.accounts) setAccounts(data.accounts);
      alert("Xogtii waa laguu soo celiyey!");
    } else {
      alert("Furahaas wax xog ah kuma xirna.");
    }
  };

  if (!currentUser) return <Login onLogin={handleLogin} accounts={accounts} />;

  return (
    <div className="min-h-screen bg-slate-50 flex font-sans overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-emerald-900 text-white flex-shrink-0 flex flex-col hidden md:flex sticky top-0 h-screen">
        <div className="p-6">
          <div className="flex items-center gap-2 mb-2">
            <span className="bg-white text-emerald-900 p-1.5 rounded-lg font-black text-xs">AH</span>
            <h1 className="text-lg font-black tracking-tight">Alhuda Herbal</h1>
          </div>
          <div className="bg-emerald-800/50 p-2 rounded-lg flex items-center gap-2 border border-emerald-700/50">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></div>
            <span className="text-[10px] font-black uppercase text-emerald-200">System Online</span>
          </div>
        </div>
        
        <nav className="flex-grow px-4 space-y-1 mt-4 overflow-y-auto custom-scrollbar">
          <NavItem icon="📊" label="Dashboard" active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} />
          <NavItem icon="🛒" label="POS (Iibka)" active={activeTab === 'pos'} onClick={() => setActiveTab('pos')} />
          <NavItem icon="🌿" label="Inventory" active={activeTab === 'inventory'} onClick={() => setActiveTab('inventory')} />
          <NavItem icon="📋" label="Patients" active={activeTab === 'patients'} onClick={() => setActiveTab('patients')} />
          <NavItem icon="📜" label="Sales History" active={activeTab === 'sales'} onClick={() => setActiveTab('sales')} />
          {['admin', 'manager'].includes(currentUser.role) && (
            <>
              <NavItem icon="💸" label="Expenses" active={activeTab === 'expenses'} onClick={() => setActiveTab('expenses')} />
              <NavItem icon="📈" label="Reports" active={activeTab === 'reports'} onClick={() => setActiveTab('reports')} />
            </>
          )}
          {currentUser.role === 'admin' && (
             <NavItem icon="⚙️" label="Settings" active={activeTab === 'settings'} onClick={() => setActiveTab('settings')} />
          )}
        </nav>

        <div className="p-4 border-t border-emerald-800 space-y-2">
           <button onClick={pushToCloud} className="w-full bg-blue-600 hover:bg-blue-500 text-[10px] font-black py-2.5 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg">
             🌐 PUSH TO CLOUD
           </button>
           <button onClick={pullFromCloud} className="w-full bg-white text-emerald-900 hover:bg-emerald-50 text-[10px] font-black py-2.5 rounded-xl transition-all flex items-center justify-center gap-2">
             ☁️ PULL FROM CLOUD
           </button>
           <div className="pt-4 flex items-center gap-3">
              <div className="w-8 h-8 bg-emerald-700 rounded-full flex items-center justify-center font-bold text-xs">
                {currentUser.username[0].toUpperCase()}
              </div>
              <div className="text-[10px]">
                <p className="font-black uppercase text-emerald-100 truncate w-32">{currentUser.username}</p>
                <button onClick={handleLogout} className="text-emerald-400 hover:text-white font-bold">Ka Bax (Sign Out)</button>
              </div>
           </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-grow overflow-y-auto h-screen bg-slate-50 relative">
        <header className="bg-white/80 backdrop-blur-md border-b border-slate-200 px-8 py-4 sticky top-0 z-40 flex justify-between items-center md:hidden">
            <h1 className="font-black text-emerald-900 tracking-tighter">ALHUDA HERBAL</h1>
            <div className="flex gap-2">
               <button onClick={pullFromCloud} className="bg-emerald-100 text-emerald-900 px-3 py-1.5 rounded-lg text-[10px] font-black">SYNC</button>
               <div className="w-8 h-8 bg-emerald-900 text-white rounded-lg flex items-center justify-center text-xs">☰</div>
            </div>
        </header>

        <div className="max-w-7xl mx-auto p-4 md:p-10 pb-24">
          {activeTab === 'dashboard' && <Dashboard products={products} sales={sales} expenses={expenses} patients={patientRecords} onAi={() => {}} aiInsight={null} loading={false} role={currentUser.role} />}
          {activeTab === 'pos' && <POS products={products} onCompleteSale={recordSale} />}
          {activeTab === 'inventory' && <Inventory products={products} role={currentUser.role} onAdd={(p) => { const np = {...p, id: Date.now().toString(), salesCount: 0}; setProducts([...products, np]); }} onUpdate={(up) => setProducts(products.map(p => p.id === up.id ? up : p))} onDelete={(id) => setProducts(products.filter(p => p.id !== id))} onSell={recordSale} />}
          {activeTab === 'patients' && <PatientRecords records={patientRecords} onAdd={addPatient} onDelete={deletePatient} />}
          {activeTab === 'sales' && <SalesHistory sales={sales} role={currentUser.role} onDelete={deleteSale} />}
          {activeTab === 'expenses' && <Expenses expenses={expenses} onAdd={addExpense} onDelete={deleteExpense} />}
          {activeTab === 'reports' && <Reports products={products} sales={sales} expenses={expenses} />}
          {activeTab === 'settings' && currentUser.role === 'admin' && <AdminSettings accounts={accounts} onUpdateAccount={(acc) => setAccounts(accounts.map(a => a.id === acc.id ? acc : a))} />}
        </div>
      </main>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 10px; }
        .animate-fade-in { animation: fadeIn 0.4s ease-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>
    </div>
  );
};

const NavItem = ({ icon, label, active, onClick }: any) => (
  <button onClick={onClick} className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl text-xs font-black transition-all ${active ? 'bg-emerald-700 text-white shadow-xl translate-x-1 ring-1 ring-emerald-600' : 'text-emerald-200 hover:bg-emerald-800'}`}>
    <span className="text-base">{icon}</span> {label.toUpperCase()}
  </button>
);

export default App;
