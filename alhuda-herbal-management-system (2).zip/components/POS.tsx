
import React, { useState, useMemo } from 'react';
import { Product, PaymentMethod } from '../types';

interface POSProps {
  products: Product[];
  onCompleteSale: (productId: string, qty: number, method: PaymentMethod) => void;
}

interface CartItem {
  product: Product;
  quantity: number;
}

const POS: React.FC<POSProps> = ({ products, onCompleteSale }) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Cash');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [showSuccess, setShowSuccess] = useState(false);
  const [isMobileCartOpen, setIsMobileCartOpen] = useState(false);
  
  const today = new Date();

  // Extract unique categories
  const categories = useMemo(() => {
    const cats = Array.from(new Set(products.map(p => p.category)));
    return ['All', ...cats];
  }, [products]);

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          p.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const addToCart = (product: Product) => {
    // BLOCK IF EXPIRED OR OUT OF STOCK
    const isExpired = product.expiryDate && new Date(product.expiryDate) < today;
    if (product.stock <= 0 || isExpired) return;

    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        if (existing.quantity >= product.stock) return prev;
        return prev.map(item => item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.product.id !== id));
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.product.id === id) {
        const newQty = item.quantity + delta;
        if (newQty <= 0) return item;
        if (newQty > item.product.stock) return item;
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const total = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  const totalItemsCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const handleCheckout = () => {
    if (cart.length === 0) return;
    
    // Process the sale
    cart.forEach(item => {
      onCompleteSale(item.product.id, item.quantity, paymentMethod);
    });
    
    setCart([]);
    setIsMobileCartOpen(false);
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  const paymentMethods: { label: PaymentMethod; color: string; icon: string }[] = [
    { label: 'EVC Plus', color: 'bg-emerald-600 border-emerald-600 text-white', icon: '📱' },
    { label: 'e-Dahab', color: 'bg-yellow-500 border-yellow-500 text-white', icon: '✨' },
    { label: 'Somnet', color: 'bg-blue-600 border-blue-600 text-white', icon: '📶' },
    { label: 'Cash', color: 'bg-slate-700 border-slate-700 text-white', icon: '💵' },
    { label: 'Card', color: 'bg-indigo-600 border-indigo-600 text-white', icon: '💳' },
  ];

  return (
    <div className="flex flex-col lg:flex-row gap-6 h-[calc(100vh-140px)] animate-fade-in relative overflow-hidden">
      {/* Success Notification overlay */}
      {showSuccess && (
        <div className="absolute inset-0 z-[100] flex items-center justify-center bg-emerald-900/40 backdrop-blur-md rounded-3xl animate-fade-in">
          <div className="bg-white p-10 rounded-[3rem] shadow-2xl text-center transform scale-110 border-4 border-emerald-500">
            <div className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <span className="text-5xl">✅</span>
            </div>
            <h2 className="text-4xl font-black text-emerald-800 mb-2">Iibka waa la dhamaystiray!</h2>
            <p className="text-emerald-600 font-bold uppercase tracking-widest">Sale Successful • Mahadsanid</p>
          </div>
        </div>
      )}

      {/* Main Product Selection Area */}
      <div className={`flex flex-col gap-6 lg:w-2/3 ${isMobileCartOpen ? 'hidden lg:flex' : 'flex'}`}>
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-grow">
            <input 
              type="text" 
              placeholder="Raadi alaabta (Search herbal products...)" 
              className="w-full bg-white border-2 border-slate-100 rounded-2xl py-4 px-12 text-lg shadow-sm focus:border-emerald-500 outline-none transition-all"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-xl opacity-40">🔍</span>
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-5 py-2.5 rounded-xl text-xs font-black whitespace-nowrap border-2 transition-all ${
                  selectedCategory === cat 
                  ? 'bg-emerald-700 border-emerald-700 text-white shadow-lg' 
                  : 'bg-white border-slate-100 text-slate-400 hover:border-emerald-200'
                }`}
              >
                {cat.toUpperCase()}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-4 overflow-y-auto pr-2 custom-scrollbar flex-grow pb-24 lg:pb-0">
          {filteredProducts.map(p => {
            const isExpired = p.expiryDate && new Date(p.expiryDate) < today;
            const isOut = p.stock <= 0;
            
            return (
              <button 
                key={p.id}
                onClick={() => addToCart(p)}
                disabled={isOut || isExpired}
                className={`bg-white p-3 rounded-[2rem] border-2 border-transparent hover:border-emerald-500 text-left transition-all group shadow-sm flex flex-col h-full relative ${isOut || isExpired ? 'opacity-50 grayscale' : ''}`}
              >
                <div className="h-32 bg-slate-50 rounded-[1.5rem] mb-3 overflow-hidden relative">
                  {p.imageUrl ? (
                    <img src={p.imageUrl} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={p.name} />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-slate-200 text-4xl">🌿</div>
                  )}
                  {isOut && (
                    <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                      <span className="bg-white text-rose-600 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-tighter">Stock Out</span>
                    </div>
                  )}
                  {isExpired && (
                    <div className="absolute inset-0 bg-rose-600/80 flex items-center justify-center">
                      <span className="bg-white text-rose-600 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-tighter">DHACDAY</span>
                    </div>
                  )}
                </div>
                <div className="px-2 pb-2 flex-grow flex flex-col">
                  <p className={`text-[10px] font-black uppercase mb-1 ${isExpired ? 'text-rose-500' : 'text-emerald-600'}`}>
                    {isExpired ? 'EXPIRED' : p.category}
                  </p>
                  <h4 className="font-bold text-slate-800 text-sm mb-2 leading-tight line-clamp-2">{p.name}</h4>
                  <div className="mt-auto flex justify-between items-center pt-2 border-t border-slate-50">
                    <span className="text-emerald-700 font-black text-xl">${p.price}</span>
                    <div className={`text-[10px] font-bold px-2 py-0.5 rounded-lg ${p.stock < 10 ? 'bg-rose-50 text-rose-600' : 'bg-slate-100 text-slate-400'}`}>
                      {p.stock}
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Cart Sidebar */}
      <div className={`lg:w-1/3 bg-white rounded-[2.5rem] shadow-2xl flex flex-col overflow-hidden border border-slate-100 transition-all duration-300 ${isMobileCartOpen ? 'flex fixed inset-0 z-50 rounded-none' : 'hidden lg:flex'}`}>
        <div className="p-8 bg-emerald-900 text-white flex justify-between items-center">
          <div>
            <h3 className="text-2xl font-black flex items-center gap-3">
              <span>🛒</span> Dalabka
            </h3>
            <p className="text-emerald-300 text-xs font-bold uppercase tracking-widest">{totalItemsCount} shay la doortay</p>
          </div>
          <button 
            onClick={() => setIsMobileCartOpen(false)}
            className="lg:hidden w-12 h-12 flex items-center justify-center bg-white/10 rounded-full text-2xl"
          >
            ✕
          </button>
        </div>

        <div className="flex-grow overflow-y-auto p-6 space-y-4 custom-scrollbar bg-slate-50/30">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-300 py-20">
              <div className="text-8xl opacity-10 mb-4">🛍️</div>
              <p className="font-black text-slate-400 uppercase tracking-widest">Dambiishaadu waa maran tahay</p>
              <p className="text-sm mt-2">Ku dar alaab si aad u iibiso</p>
            </div>
          ) : (
            cart.map(item => (
              <div key={item.product.id} className="flex items-center gap-4 bg-white p-4 rounded-[1.5rem] shadow-sm border border-slate-100 group">
                <div className="w-14 h-14 rounded-2xl bg-slate-50 overflow-hidden flex-shrink-0 border border-slate-100">
                  {item.product.imageUrl ? <img src={item.product.imageUrl} className="w-full h-full object-cover" alt="" /> : <div className="w-full h-full flex items-center justify-center">🌿</div>}
                </div>
                <div className="flex-grow min-w-0">
                  <h5 className="text-sm font-black text-slate-700 truncate">{item.product.name}</h5>
                  <p className="text-xs text-emerald-600 font-bold">${item.product.price} x {item.quantity}</p>
                </div>
                <div className="flex items-center gap-1 bg-slate-50 rounded-xl p-1">
                  <button onClick={() => updateQuantity(item.product.id, -1)} className="w-8 h-8 flex items-center justify-center hover:bg-white rounded-lg font-black text-slate-400 hover:text-emerald-600 transition-all shadow-sm">-</button>
                  <span className="text-sm font-black w-6 text-center">{item.quantity}</span>
                  <button onClick={() => updateQuantity(item.product.id, 1)} className="w-8 h-8 flex items-center justify-center hover:bg-white rounded-lg font-black text-slate-400 hover:text-emerald-600 transition-all shadow-sm">+</button>
                </div>
                <button onClick={() => removeFromCart(item.product.id)} className="w-8 h-8 flex items-center justify-center text-rose-300 hover:text-rose-600 hover:bg-rose-50 rounded-full transition-all text-xl font-bold">✕</button>
              </div>
            ))
          )}
        </div>

        <div className="p-8 bg-white border-t border-slate-100 space-y-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-xs font-black text-slate-400 uppercase tracking-widest">Lacag Bixinta (Method)</label>
              <span className="text-[10px] font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">{paymentMethod}</span>
            </div>
            <div className="grid grid-cols-5 gap-2">
              {paymentMethods.map(m => (
                <button 
                  key={m.label}
                  onClick={() => setPaymentMethod(m.label)}
                  className={`flex flex-col items-center justify-center py-3 rounded-2xl border-2 transition-all ${
                    paymentMethod === m.label 
                    ? `${m.color} shadow-lg scale-105 ring-4 ring-emerald-50` 
                    : 'bg-slate-50 border-transparent text-slate-400 hover:border-slate-200'
                  }`}
                >
                  <span className="text-xl mb-1">{m.icon}</span>
                  <span className="text-[8px] font-black uppercase text-center leading-tight whitespace-nowrap">{m.label.split(' ')[0]}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100">
             <div className="flex justify-between items-end mb-6">
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Wadarta Guud (Total)</p>
                  <p className="text-5xl font-black text-emerald-800 tracking-tighter">${total.toFixed(2)}</p>
                </div>
                <div className="text-right">
                   <p className="text-[10px] font-black text-slate-400 uppercase mb-1">Items</p>
                   <p className="text-xl font-black text-slate-600">{totalItemsCount}</p>
                </div>
             </div>
             
             <button 
                onClick={handleCheckout}
                disabled={cart.length === 0}
                className={`w-full py-5 rounded-[1.5rem] font-black text-xl shadow-2xl transition-all flex items-center justify-center gap-3 ${
                  cart.length === 0 
                  ? 'bg-slate-100 text-slate-300 cursor-not-allowed' 
                  : 'bg-emerald-600 text-white hover:bg-emerald-700 hover:-translate-y-1 active:translate-y-0 shadow-emerald-200'
                }`}
              >
                <span>Bixi Hadda</span>
                <span className="text-white/50">|</span>
                <span>Checkout</span>
              </button>
          </div>
        </div>
      </div>

      {/* Floating Mobile Cart Button */}
      <button 
        onClick={() => setIsMobileCartOpen(true)}
        className={`lg:hidden fixed bottom-6 right-6 w-20 h-20 bg-emerald-600 text-white rounded-full shadow-2xl flex flex-col items-center justify-center z-40 animate-bounce-subtle ${isMobileCartOpen ? 'hidden' : 'flex'}`}
      >
        <span className="text-3xl">🛒</span>
        {totalItemsCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[10px] font-black px-2 py-1 rounded-full border-2 border-white">
            {totalItemsCount}
          </span>
        )}
      </button>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 10px; }
        .animate-bounce-subtle { animation: bounce-subtle 3s infinite; }
        @keyframes bounce-subtle {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
      `}</style>
    </div>
  );
};

export default POS;
