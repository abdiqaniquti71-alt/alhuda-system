
import React, { useState } from 'react';
import { User, Account } from '../types';

interface LoginProps {
  onLogin: (user: User) => void;
  accounts: Account[];
}

const Login: React.FC<LoginProps> = ({ onLogin, accounts }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const account = accounts.find(
      acc => acc.username.toLowerCase() === username.toLowerCase() && acc.password === password
    );

    if (account) {
      onLogin({ id: account.id, username: account.username, role: account.role });
    } else {
      setError('Username ama Password waa khalad. Fadlan iska hubi.');
    }
  };

  return (
    <div className="min-h-screen bg-emerald-900 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden animate-fade-in border-4 border-emerald-800">
        <div className="bg-emerald-700 p-10 text-white text-center">
          <div className="w-20 h-20 bg-white rounded-[1.5rem] mx-auto mb-4 flex items-center justify-center shadow-lg">
            <svg className="w-12 h-12 text-emerald-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <h2 className="text-3xl font-black">Alhuda Herbal</h2>
          <p className="text-emerald-100 text-sm font-medium mt-1">Management System Login</p>
        </div>
        
        <form onSubmit={handleSubmit} className="p-10 space-y-6">
          {error && (
            <div className="bg-rose-50 border border-rose-100 text-rose-600 px-4 py-3 rounded-xl text-xs font-bold animate-shake">
              ⚠️ {error}
            </div>
          )}

          <div>
            <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Username</label>
            <input 
              type="text"
              required
              className="w-full bg-slate-50 border-2 border-transparent rounded-2xl p-4 text-sm font-bold focus:border-emerald-500 outline-none transition-all"
              placeholder="Gali magacaaga"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>

          <div>
            <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Password</label>
            <input 
              type="password"
              required
              className="w-full bg-slate-50 border-2 border-transparent rounded-2xl p-4 text-sm font-bold focus:border-emerald-500 outline-none transition-all"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          <button 
            type="submit"
            className="w-full bg-emerald-600 text-white font-black py-5 rounded-2xl shadow-xl shadow-emerald-100 hover:bg-emerald-700 transition-all hover:-translate-y-1 active:translate-y-0"
          >
            Access System (Gali)
          </button>
          
          <div className="text-center">
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
              Admin Default: admin / admin123
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;
