
import React from 'react';
import { Sale, Expense, Product } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';

interface ReportsProps {
  sales: Sale[];
  expenses: Expense[];
  products: Product[];
}

const Reports: React.FC<ReportsProps> = ({ sales, expenses, products }) => {
  // 1. Total Sales (Dakhliga Guud)
  const totalRevenue = sales.reduce((a, b) => a + (b.totalPrice || 0), 0);

  // 2. Cost of Goods Sold (COGS)
  const totalCOGS = sales.reduce((sum, sale) => {
    const product = products.find(p => p.id === sale.productId);
    const unitCost = product?.cost || 0;
    return sum + (unitCost * sale.quantity);
  }, 0);

  // 3. Gross Profit (Macaashka Iibka)
  const grossProfit = totalRevenue - totalCOGS;

  // 4. Expenses (Kharashyada kale)
  const totalExpenses = expenses.reduce((a, b) => a + (b.amount || 0), 0);

  // 5. Net Profit (Faa'iidada dhabta ah)
  const netProfit = grossProfit - totalExpenses;

  const summaryData = [
    { name: 'Revenue', value: totalRevenue, fill: '#059669', label: 'Dakhliga' },
    { name: 'Cost', value: totalCOGS, fill: '#f59e0b', label: 'Iibka/Cost' },
    { name: 'Expenses', value: totalExpenses, fill: '#e11d48', label: 'Kharashka' },
    { name: 'Profit', value: netProfit, fill: '#6366f1', label: 'Faa\'iido' }
  ];

  if (sales.length === 0 && expenses.length === 0) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-center p-8 bg-white rounded-[3rem] border-2 border-dashed border-slate-100">
        <div className="text-8xl mb-6">📊</div>
        <h3 className="text-2xl font-black text-slate-800 mb-2">Ma jirto xog weli muuqata</h3>
        <p className="text-slate-500 max-w-md mx-auto mb-8">
          Haddii aad xog hore lahayd, fadlan isticmaal <b>"PULL FROM CLOUD"</b> ee dhinaca bidix ku yaal si aad xogtaadii u soo celiso.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-black text-slate-800">Warbixinta Maaliyadda</h2>
          <p className="text-sm text-slate-500">Kormeerka dhaqdhaqaaqa ganacsiga internet-ka</p>
        </div>
        <div className="bg-emerald-900 text-white px-10 py-5 rounded-[2.5rem] shadow-2xl text-right">
            <p className="text-[10px] font-black uppercase tracking-[0.2em] opacity-60 mb-1">Faa'iidada Saafiga ah</p>
            <p className="text-4xl font-black tracking-tighter">${netProfit.toLocaleString()}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <ReportCard label="Revenue" value={`$${totalRevenue.toLocaleString()}`} icon="💰" color="text-emerald-600" bg="bg-emerald-50" desc="Dakhliga iibka" />
        <ReportCard label="Inventory Cost" value={`$${totalCOGS.toLocaleString()}`} icon="🦴" color="text-amber-600" bg="bg-amber-50" desc="Lacagta alaabtu ku kacday" />
        <ReportCard label="Operational Exp" value={`$${totalExpenses.toLocaleString()}`} icon="💸" color="text-rose-600" bg="bg-rose-50" desc="Kharashka adeegga" />
        <ReportCard label="Net Profit" value={`$${netProfit.toLocaleString()}`} icon="✨" color="text-indigo-600" bg="bg-indigo-50" desc="Faa'iidada hartay" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-10 rounded-[3rem] shadow-sm border border-slate-100">
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-10 text-center">Muuqaalka Maaliyadda</h3>
            <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={summaryData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="label" axisLine={false} tickLine={false} fontSize={10} fontWeight="bold" />
                        <YAxis axisLine={false} tickLine={false} fontSize={10} />
                        <Tooltip contentStyle={{ borderRadius: '24px', border: 'none', boxShadow: '0 25px 50px -12px rgb(0 0 0 / 0.1)' }} />
                        <Bar dataKey="value" radius={[15, 15, 0, 0]} barSize={60}>
                           {summaryData.map((entry, index) => (
                             <Cell key={`cell-${index}`} fill={entry.fill} />
                           ))}
                        </Bar>
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </div>

        <div className="bg-emerald-900 p-10 rounded-[3rem] text-white flex flex-col justify-center shadow-xl">
            <h3 className="text-xl font-black mb-8">Xisaabta Meheradda</h3>
            <div className="space-y-6">
                <div className="flex justify-between border-b border-emerald-800 pb-4">
                    <span className="text-emerald-300">Dakhli</span>
                    <span className="font-black">+ ${totalRevenue.toLocaleString()}</span>
                </div>
                <div className="flex justify-between border-b border-emerald-800 pb-4">
                    <span className="text-emerald-300">Qiimaha Alaabta</span>
                    <span className="font-black text-amber-400">- ${totalCOGS.toLocaleString()}</span>
                </div>
                <div className="flex justify-between border-b border-emerald-800 pb-4">
                    <span className="text-emerald-300">Kharash kale</span>
                    <span className="font-black text-rose-400">- ${totalExpenses.toLocaleString()}</span>
                </div>
                <div className="pt-4 flex justify-between items-center text-2xl font-black">
                    <span className="text-white text-sm">TOTAL PROFIT</span>
                    <span className="text-emerald-400">${netProfit.toLocaleString()}</span>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

const ReportCard = ({ label, value, icon, color, bg, desc }: any) => (
  <div className={`p-8 rounded-[2.5rem] border border-slate-100 shadow-sm transition-all hover:shadow-lg ${bg}`}>
    <div className="flex items-center justify-between mb-4">
      <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-xl shadow-sm">{icon}</div>
      <div className="text-right">
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{label}</p>
        <p className={`text-xl font-black ${color}`}>{value}</p>
      </div>
    </div>
    <p className="text-[10px] font-bold text-slate-400 uppercase opacity-50 border-t border-slate-200/50 pt-4 mt-4">{desc}</p>
  </div>
);

export default Reports;
