
import React from 'react';
import { Product, Sale, Expense, PatientRecord, UserRole } from '../types';

interface DashboardProps {
  products: Product[];
  sales: Sale[];
  expenses: Expense[];
  patients: PatientRecord[];
  onAi: () => void;
  aiInsight: string | null;
  loading: boolean;
  role: UserRole;
}

const Dashboard: React.FC<DashboardProps> = ({ products, sales, expenses, patients, role }) => {
  const isCashier = role === 'cashier';
  
  const totalRevenue = sales.reduce((a, b) => a + (b.totalPrice || 0), 0);
  const totalCOGS = sales.reduce((sum, sale) => {
    const product = products.find(p => p.id === sale.productId);
    return sum + ((product?.cost || 0) * sale.quantity);
  }, 0);
  const totalExpenses = expenses.reduce((a, b) => a + (b.amount || 0), 0);
  const netProfit = totalRevenue - totalCOGS - totalExpenses;

  return (
    <div className="space-y-10 animate-fade-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <h2 className="text-4xl font-black text-slate-900 tracking-tight">Dashboard</h2>
          <p className="text-slate-500 font-medium">Halkan kala soco dhaqdhaqaaqa ganacsigaaga</p>
        </div>
        <div className="bg-emerald-100 text-emerald-800 px-6 py-3 rounded-2xl border border-emerald-200 shadow-sm flex items-center gap-3">
            <span className="text-xl">📅</span>
            <div className="text-left">
                <p className="text-[10px] font-black uppercase opacity-60">Maanta waa</p>
                <p className="text-sm font-black">{new Date().toLocaleDateString('so-SO', { weekday: 'long', month: 'long', day: 'numeric' })}</p>
            </div>
        </div>
      </div>

      <div className={`grid grid-cols-1 md:grid-cols-2 ${isCashier ? 'lg:grid-cols-2' : 'lg:grid-cols-4'} gap-6`}>
        <StatCard label="Dakhliga (Revenue)" value={`$${totalRevenue.toLocaleString()}`} icon="💰" color="text-emerald-600" bg="bg-emerald-50" />
        {!isCashier && (
          <>
            <StatCard label="Kharashka (Expenses)" value={`$${totalExpenses.toLocaleString()}`} icon="💸" color="text-rose-600" bg="bg-rose-50" />
            <StatCard label="Faa'iidada (Profit)" value={`$${netProfit.toLocaleString()}`} icon="📈" color="text-blue-600" bg="bg-blue-50" />
          </>
        )}
        <StatCard label="Bukaanada (Patients)" value={patients.length} icon="🏥" color="text-indigo-600" bg="bg-indigo-50" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sync Guide - Solving the "Data 0" problem */}
        <div className="lg:col-span-2 bg-white p-10 rounded-[3rem] shadow-sm border border-slate-100 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 text-6xl opacity-10 grayscale">🌐</div>
            <h3 className="text-2xl font-black text-slate-800 mb-6 flex items-center gap-3">
                <span className="bg-blue-100 p-2 rounded-xl">☁️</span>
                Sida looga isticmaalo magaalo kale?
            </h3>
            <div className="space-y-6">
                <p className="text-slate-500 font-medium leading-relaxed">
                    Si xogtaadu aysan "0" u noqon markaad browser kale ama magaalo kale ka gasho, fadlan raac talaabooyinkan fudud:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-slate-50 p-6 rounded-[2rem] border border-slate-100">
                        <span className="bg-blue-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-black mb-4">1</span>
                        <h4 className="font-black text-slate-800 mb-2">Step 1: PUSH</h4>
                        <p className="text-xs text-slate-500">Kumbuyuutarka xogta leh, riix <b>PUSH TO CLOUD</b> oo geli magac aad xasuusan karto (tusaale: alhuda_sync).</p>
                    </div>
                    <div className="bg-emerald-50 p-6 rounded-[2rem] border border-emerald-100">
                        <span className="bg-emerald-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-black mb-4">2</span>
                        <h4 className="font-black text-emerald-800 mb-2">Step 2: PULL</h4>
                        <p className="text-xs text-emerald-600">Kumbuyuutarka cusub ama browser-ka cusub ka gal, riix <b>PULL FROM CLOUD</b> oo geli isla magacaas.</p>
                    </div>
                </div>
                <div className="mt-4 p-4 bg-amber-50 border border-amber-100 rounded-2xl flex items-center gap-4 text-amber-700">
                    <span className="text-2xl">💡</span>
                    <p className="text-xs font-bold">Xusuusin: Xogta waxaa lagu kaydiyaa browser-ka dhexdiisa si nidaamku u shaqeeyo isagoo Offline ah.</p>
                </div>
            </div>
        </div>

        {/* Inventory Summary */}
        <div className="bg-emerald-900 p-10 rounded-[3rem] shadow-2xl text-white">
            <h3 className="text-xl font-black mb-8 flex items-center gap-3">
                <span className="text-2xl">📦</span>
                Xaaladda Kaydka
            </h3>
            <div className="space-y-8">
                <div>
                   <div className="flex justify-between text-[10px] font-black uppercase mb-2 tracking-widest text-emerald-300">
                      <span>Total Products</span>
                      <span>{products.length} Items</span>
                   </div>
                   <div className="h-3 bg-emerald-800 rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-400" style={{width: '75%'}}></div>
                   </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                   <div className="bg-emerald-800/50 p-4 rounded-2xl">
                      <p className="text-[10px] font-black text-emerald-300 uppercase">Expired</p>
                      <p className="text-2xl font-black text-rose-400">{products.filter(p => p.expiryDate && new Date(p.expiryDate) < new Date()).length}</p>
                   </div>
                   <div className="bg-emerald-800/50 p-4 rounded-2xl">
                      <p className="text-[10px] font-black text-emerald-300 uppercase">Low Stock</p>
                      <p className="text-2xl font-black text-amber-400">{products.filter(p => p.stock <= 5 && p.stock > 0).length}</p>
                   </div>
                </div>

                <div className="pt-6 border-t border-emerald-800">
                   <p className="text-[10px] font-black text-emerald-400 uppercase mb-4 tracking-tighter">Iibka ugu badan (Top Seller)</p>
                   {products.length > 0 ? (
                       <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center text-xl">🌿</div>
                          <div>
                             <p className="font-black text-sm truncate w-32">{[...products].sort((a,b) => b.salesCount - a.salesCount)[0].name}</p>
                             <p className="text-[10px] text-emerald-400">Sold: {[...products].sort((a,b) => b.salesCount - a.salesCount)[0].salesCount}</p>
                          </div>
                       </div>
                   ) : <p className="text-xs italic opacity-50">Ma jirto xog</p>}
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ label, value, icon, color, bg }: any) => (
  <div className={`${bg} p-8 rounded-[2.5rem] border border-slate-100 shadow-sm transition-all hover:shadow-xl hover:-translate-y-1`}>
    <div className="bg-white w-14 h-14 rounded-2xl flex items-center justify-center text-2xl shadow-sm mb-6">{icon}</div>
    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{label}</p>
    <p className={`text-3xl font-black ${color} tracking-tighter`}>{value}</p>
  </div>
);

export default Dashboard;
