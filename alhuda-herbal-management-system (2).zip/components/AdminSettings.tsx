
import React, { useState } from 'react';
import { Account } from '../types';

interface SettingsProps {
  accounts: Account[];
  onUpdateAccount: (acc: Account) => void;
}

const AdminSettings: React.FC<SettingsProps> = ({ accounts, onUpdateAccount }) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newPassword, setNewPassword] = useState('');

  const handleUpdate = (acc: Account) => {
    if (newPassword.length < 4) {
      alert("Password-ku waa inuu ka badnaadaa 4 xaraf.");
      return;
    }
    onUpdateAccount({ ...acc, password: newPassword });
    setEditingId(null);
    setNewPassword('');
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <div>
        <h2 className="text-3xl font-black text-gray-800">Admin Settings</h2>
        <p className="text-sm text-gray-500">Maamul dadka nidaamka isticmaala iyo password-kooda</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {accounts.map(acc => (
          <div key={acc.id} className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100 hover:shadow-xl transition-all relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-50 rounded-bl-[4rem] -mr-8 -mt-8 transition-all group-hover:scale-110"></div>
            
            <div className="relative z-10">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-2xl flex items-center justify-center text-xl font-black">
                  {acc.username[0].toUpperCase()}
                </div>
                <div>
                  <h4 className="font-black text-lg text-slate-800 capitalize">{acc.username}</h4>
                  <span className="text-[10px] font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full uppercase tracking-widest">
                    {acc.role}
                  </span>
                </div>
              </div>

              {editingId === acc.id ? (
                <div className="space-y-4 animate-slide-up">
                  <input 
                    type="text"
                    className="w-full bg-slate-50 border-2 border-emerald-500 rounded-xl p-3 text-sm font-bold outline-none"
                    placeholder="New Password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    autoFocus
                  />
                  <div className="flex gap-2">
                    <button 
                      onClick={() => handleUpdate(acc)}
                      className="flex-grow bg-emerald-600 text-white py-2.5 rounded-xl text-xs font-black shadow-lg hover:bg-emerald-700 transition-all"
                    >
                      SAVE
                    </button>
                    <button 
                      onClick={() => setEditingId(null)}
                      className="px-4 bg-slate-100 text-slate-400 py-2.5 rounded-xl text-xs font-black hover:bg-slate-200"
                    >
                      X
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                    <p className="text-[10px] font-black text-slate-400 uppercase mb-1">Current Password</p>
                    <p className="text-lg font-mono font-black text-slate-700 tracking-tighter">
                      {acc.password.replace(/./g, '•')}
                    </p>
                  </div>
                  <button 
                    onClick={() => setEditingId(acc.id)}
                    className="w-full bg-slate-800 text-white py-3 rounded-xl text-xs font-black hover:bg-black transition-all shadow-md"
                  >
                    CHANGE PASSWORD
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="bg-emerald-50 p-8 rounded-[2rem] border border-emerald-100 flex items-center gap-6">
        <div className="text-4xl">🔐</div>
        <div>
          <h4 className="font-black text-emerald-900">Beddelista Password-ka</h4>
          <p className="text-sm text-emerald-700 opacity-80">
            Admin ahaan, waxaad awood u leedahay inaad beddesho password-ka qof kasta oo nidaamka isticmaala haddii uu ilaaway ama aad rabto inaad ammaan ku kordhiso.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AdminSettings;
