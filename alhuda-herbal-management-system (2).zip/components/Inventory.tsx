
import React, { useState, useRef, useEffect } from 'react';
import { Product, UserRole } from '../types';

interface InventoryProps {
  products: Product[];
  role: UserRole;
  onAdd: (p: Omit<Product, 'id' | 'salesCount'>) => void;
  onUpdate: (p: Product) => void;
  onDelete: (id: string) => void;
  onSell: (id: string, qty: number) => void;
}

const Inventory: React.FC<InventoryProps> = ({ products, role, onAdd, onUpdate, onDelete, onSell }) => {
  const [showAdd, setShowAdd] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [formData, setFormData] = useState({ 
    name: '', 
    price: 0, 
    cost: 0, 
    stock: 0, 
    category: 'General', 
    imageUrl: '',
    expiryDate: '' 
  });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const isCashier = role === 'cashier';
  const today = new Date();

  // Update form data when entering Edit Mode
  useEffect(() => {
    if (editingProduct) {
      setFormData({
        name: editingProduct.name,
        price: editingProduct.price,
        cost: editingProduct.cost,
        stock: editingProduct.stock,
        category: editingProduct.category,
        imageUrl: editingProduct.imageUrl || '',
        expiryDate: editingProduct.expiryDate || ''
      });
      setShowAdd(true);
    }
  }, [editingProduct]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, imageUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) return;

    if (editingProduct) {
      onUpdate({ ...editingProduct, ...formData });
      setEditingProduct(null);
    } else {
      onAdd(formData);
    }

    setFormData({ name: '', price: 0, cost: 0, stock: 0, category: 'General', imageUrl: '', expiryDate: '' });
    setShowAdd(false);
  };

  const closeForm = () => {
    setShowAdd(false);
    setEditingProduct(null);
    setFormData({ name: '', price: 0, cost: 0, stock: 0, category: 'General', imageUrl: '', expiryDate: '' });
  };

  const isAdmin = role === 'admin' || role === 'manager';

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800">Kaydka Dawaada (Medicinal Inventory)</h2>
        {isAdmin && (
          <button 
            onClick={() => showAdd ? closeForm() : setShowAdd(true)}
            className="bg-emerald-600 text-white px-5 py-2.5 rounded-xl font-bold shadow-lg hover:bg-emerald-700 transition-all flex items-center gap-2"
          >
            {showAdd ? 'Xir (Close)' : 'Kudar Dawa Cusub (Add New)'}
          </button>
        )}
      </div>

      {showAdd && isAdmin && (
        <form onSubmit={handleSave} className="bg-white p-8 rounded-[2.5rem] border border-emerald-100 shadow-xl grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-slide-down">
          <div className="space-y-4">
            <Input label="Magaca (Product Name)" value={formData.name} onChange={v => setFormData({...formData, name: v})} />
            <Input label="Qiimaha Iibka (Selling Price $)" type="number" value={formData.price} onChange={v => setFormData({...formData, price: parseFloat(v) || 0})} />
            <Input label="Qiimaha Lagu Soo Iibiyey (Cost $)" type="number" value={formData.cost} onChange={v => setFormData({...formData, cost: parseFloat(v) || 0})} />
          </div>
          <div className="space-y-4">
            <Input label="Tirada Stock-ga (Quantity)" type="number" value={formData.stock} onChange={v => setFormData({...formData, stock: parseInt(v) || 0})} />
            <Input label="Nooca (Category)" value={formData.category} onChange={v => setFormData({...formData, category: v})} />
            <Input label="Taariikhda Dhicitaanka (Expiry Date)" type="date" value={formData.expiryDate} onChange={v => setFormData({...formData, expiryDate: v})} />
          </div>
          
          <div className="flex flex-col">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Sawirka (Product Image)</label>
              <div className="flex gap-2 h-full">
                <div className="flex-grow bg-slate-50 border-2 border-dashed border-slate-200 rounded-xl p-4 flex flex-col items-center justify-center gap-2">
                  {formData.imageUrl ? (
                    <div className="relative w-full h-full flex items-center justify-center">
                      <img src={formData.imageUrl} className="max-h-32 rounded-lg object-contain" alt="Preview" />
                      <button type="button" onClick={() => setFormData({...formData, imageUrl: ''})} className="absolute -top-2 -right-2 bg-rose-500 text-white w-6 h-6 rounded-full text-xs">✕</button>
                    </div>
                  ) : (
                    <div className="text-center">
                      <p className="text-[10px] font-bold text-slate-400 mb-2">NO IMAGE</p>
                      <button 
                        type="button" 
                        onClick={() => fileInputRef.current?.click()}
                        className="bg-white border border-slate-200 px-3 py-1 rounded-lg text-[10px] font-black hover:bg-slate-50"
                      >
                        UPLOAD
                      </button>
                    </div>
                  )}
                </div>
                <input type="file" accept="image/*" className="hidden" ref={fileInputRef} onChange={handleFileChange} />
              </div>
          </div>

          <button className="lg:col-span-3 bg-emerald-600 text-white py-5 rounded-2xl font-black text-lg mt-2 shadow-2xl shadow-emerald-200 hover:bg-emerald-700 hover:-translate-y-1 active:translate-y-0 transition-all">
            {editingProduct ? 'Cusboonaysii Dawaada (Update Product)' : 'Keydi Dawaada (Save Product)'}
          </button>
        </form>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {products.map(p => {
          const isExpired = p.expiryDate && new Date(p.expiryDate) < today;
          
          return (
            <div key={p.id} className={`bg-white rounded-[2rem] shadow-sm border overflow-hidden flex flex-col hover:shadow-xl transition-all group ${isExpired ? 'border-rose-200' : 'border-gray-100'}`}>
              <div className="h-56 bg-slate-100 relative overflow-hidden">
                {p.imageUrl ? (
                  <img src={p.imageUrl} alt={p.name} className={`w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ${isExpired ? 'grayscale' : ''}`} />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-200">
                    <span className="text-6xl">🌿</span>
                  </div>
                )}
                
                {/* Status Badges */}
                <div className="absolute top-4 left-4 flex flex-col gap-2">
                  <div className="bg-emerald-900/90 backdrop-blur-md px-4 py-1.5 rounded-full text-[10px] font-black text-white uppercase tracking-widest shadow-lg">
                    {p.category}
                  </div>
                  {isExpired && (
                    <div className="bg-rose-600 px-4 py-1.5 rounded-full text-[10px] font-black text-white uppercase tracking-widest shadow-lg animate-pulse">
                      DHACDAY (EXPIRED)
                    </div>
                  )}
                </div>

                {p.stock <= 5 && p.stock > 0 && !isExpired && (
                  <div className="absolute top-4 right-4 bg-amber-500 text-white px-3 py-1 rounded-full text-[10px] font-black uppercase">
                    Low Stock
                  </div>
                )}

                {isAdmin && (
                  <button 
                    onClick={() => {
                      if (window.confirm(`Ma hubtaa in aad tirtirto ${p.name}?`)) {
                        onDelete(p.id);
                      }
                    }}
                    className="absolute bottom-4 right-4 bg-rose-500/80 backdrop-blur hover:bg-rose-600 text-white p-2 rounded-xl opacity-0 group-hover:opacity-100 transition-all shadow-lg"
                    title="Delete Product"
                  >
                    🗑️
                  </button>
                )}
              </div>

              <div className="p-6 flex-grow flex flex-col">
                <h3 className={`font-black text-lg leading-tight mb-2 truncate ${isExpired ? 'text-rose-800' : 'text-gray-800 group-hover:text-emerald-700'}`}>
                  {p.name}
                </h3>
                
                {p.expiryDate && (
                  <p className={`text-[10px] font-black uppercase mb-4 ${isExpired ? 'text-rose-500' : 'text-slate-400'}`}>
                    Exp: {p.expiryDate}
                  </p>
                )}
                
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className={`bg-slate-50 p-3 rounded-2xl border border-slate-100 ${isCashier ? 'col-span-2' : ''}`}>
                     <p className="text-[10px] font-black text-slate-400 uppercase leading-none mb-1">Selling</p>
                     <span className="text-emerald-700 font-black text-xl">${p.price.toFixed(2)}</span>
                  </div>
                  {!isCashier && (
                    <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100">
                       <p className="text-[10px] font-black text-slate-400 uppercase leading-none mb-1">Cost</p>
                       <span className="text-rose-500 font-black text-xl">${p.cost?.toFixed(2) || '0.00'}</span>
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between mb-6 px-1">
                  <div className="flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${p.stock > 10 && !isExpired ? 'bg-emerald-500' : isExpired ? 'bg-rose-600' : 'bg-rose-500'}`}></div>
                    <span className="text-xs font-black text-slate-500 uppercase">Stock: {p.stock}</span>
                  </div>
                  {!isCashier && !isExpired && (
                    <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-lg">
                      Profit: +${(p.price - (p.cost || 0)).toFixed(2)}
                    </span>
                  )}
                  {isExpired && !isCashier && (
                    <span className="text-[10px] font-bold text-rose-600 bg-rose-50 px-2 py-1 rounded-lg">
                      Loss: -${(p.cost * p.stock).toFixed(2)}
                    </span>
                  )}
                </div>

                <div className="mt-auto flex gap-2">
                  <button 
                    onClick={() => onSell(p.id, 1)}
                    disabled={p.stock <= 0 || isExpired}
                    className={`flex-grow py-4 rounded-2xl text-white font-black transition-all shadow-lg ${p.stock <= 0 || isExpired ? 'bg-slate-200 cursor-not-allowed shadow-none text-slate-400' : 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-100 hover:-translate-y-1'}`}
                  >
                    {isExpired ? 'MA IIB-KARO' : p.stock <= 0 ? 'DHAMMAAD' : 'IIBI (SELL)'}
                  </button>
                  {isAdmin && (
                    <button 
                      onClick={() => setEditingProduct(p)}
                      className="p-4 bg-slate-50 rounded-2xl text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 transition-all border border-slate-100"
                      title="Edit Product"
                    >
                      ✏️
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const Input = ({ label, type = 'text', value, onChange }: any) => (
  <div>
    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">{label}</label>
    <input 
      type={type}
      className="w-full bg-slate-50 border-2 border-transparent rounded-xl p-4 text-sm font-bold text-slate-700 focus:border-emerald-500 focus:bg-white outline-none transition-all shadow-sm"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      required={type !== 'date'}
    />
  </div>
);

export default Inventory;
