
import React from 'react';
import { Sale, UserRole } from '../types';

interface SalesProps {
  sales: Sale[];
  role: UserRole;
  onDelete: (id: string) => void;
}

const SalesHistory: React.FC<SalesProps> = ({ sales, role, onDelete }) => {
  const isAdmin = role === 'admin' || role === 'manager';

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`Ma hubtaa inaad tirtirto iibka: ${name}? \nAlaabtu waxay ku noqon doontaa Inventory-ga.`)) {
      onDelete(id);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Diiwaanka Iibka</h2>
          <p className="text-sm text-gray-500">History of all transactions</p>
        </div>
        <div className="bg-emerald-50 px-4 py-2 rounded-xl border border-emerald-100">
           <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">Total Sales: {sales.length}</span>
        </div>
      </div>

      <div className="bg-white rounded-[2.5rem] shadow-sm border border-gray-100 overflow-hidden">
        {sales.length > 0 ? (
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">
              <tr>
                <th className="px-8 py-5">Date</th>
                <th className="px-8 py-5">Product</th>
                <th className="px-8 py-5 text-center">Qty</th>
                <th className="px-8 py-5">Payment</th>
                <th className="px-8 py-5 text-right">Total ($)</th>
                {isAdmin && <th className="px-8 py-5 text-center">Action</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {sales.map(sale => (
                <tr key={sale.id} className="hover:bg-slate-50/50 transition-all">
                  <td className="px-8 py-5 text-slate-500 text-xs">
                    {new Date(sale.timestamp).toLocaleString()}
                  </td>
                  <td className="px-8 py-5 font-bold text-slate-800">{sale.productName}</td>
                  <td className="px-8 py-5 text-center font-black text-slate-400">{sale.quantity}</td>
                  <td className="px-8 py-5 text-xs font-black text-emerald-600">{sale.paymentMethod}</td>
                  <td className="px-8 py-5 text-right font-black text-emerald-700 text-lg">
                    ${sale.totalPrice.toFixed(2)}
                  </td>
                  {isAdmin && (
                    <td className="px-8 py-5 text-center">
                      <button 
                        onClick={() => handleDelete(sale.id, sale.productName)}
                        className="w-10 h-10 bg-rose-50 text-rose-500 hover:bg-rose-500 hover:text-white rounded-xl transition-all shadow-sm flex items-center justify-center"
                      >
                        🗑️
                      </button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="py-24 text-center text-slate-300 italic">Ma jiro iib weli la sameeyay.</div>
        )}
      </div>
    </div>
  );
};

export default SalesHistory;
