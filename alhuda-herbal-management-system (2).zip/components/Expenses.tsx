
import React, { useState } from 'react';
import { Expense } from '../types';

interface ExpenseProps {
  expenses: Expense[];
  onAdd: (e: Omit<Expense, 'id' | 'timestamp'>) => void;
  onDelete: (id: string) => void;
}

const Expenses: React.FC<ExpenseProps> = ({ expenses, onAdd, onDelete }) => {
  const [formData, setFormData] = useState({ description: '', amount: 0, category: 'General' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.amount <= 0 || !formData.description) {
      alert("Fadlan geli sharaxaad iyo lacag sax ah.");
      return;
    }
    onAdd(formData);
    setFormData({ description: '', amount: 0, category: 'General' });
    alert("Kharashkii waa la diiwangeliyey!");
  };

  const total = expenses.reduce((a, b) => a + b.amount, 0);

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex justify-between items-center">
        <div>
            <h2 className="text-2xl font-black text-slate-800">Diiwaanka Kharashyada (Expenses)</h2>
            <p className="text-sm text-slate-500">Halkan ku qor dhammaan lacagaha ganacsiga ka baxa</p>
        </div>
        <div className="bg-rose-50 px-6 py-4 rounded-[2rem] border border-rose-100 shadow-sm text-right">
            <span className="text-[10px] font-black text-rose-400 uppercase tracking-widest block mb-1">Total Expenses</span>
            <p className="text-2xl font-black text-rose-600">${total.toLocaleString()}</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="md:col-span-2">
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Sharaxaad (Description)</label>
            <input 
                className="w-full bg-slate-50 border-2 border-transparent rounded-2xl p-4 text-sm font-bold focus:border-rose-500 outline-none transition-all"
                placeholder="Tusaale: Korontada, Mushaar, Kirada..."
                value={formData.description}
                onChange={e => setFormData({...formData, description: e.target.value})}
                required
            />
        </div>
        <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Lacagta (Amount $)</label>
            <input 
                type="number"
                step="0.01"
                className="w-full bg-slate-50 border-2 border-transparent rounded-2xl p-4 text-sm font-bold focus:border-rose-500 outline-none transition-all"
                value={formData.amount || ''}
                onChange={e => setFormData({...formData, amount: parseFloat(e.target.value) || 0})}
                required
            />
        </div>
        <div className="flex items-end">
            <button className="w-full bg-rose-600 text-white font-black py-4 rounded-2xl shadow-xl shadow-rose-100 hover:bg-rose-700 hover:-translate-y-1 transition-all">
                ADD EXPENSE
            </button>
        </div>
      </form>

      <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-100 overflow-hidden">
        {expenses.length > 0 ? (
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">
              <tr>
                <th className="px-8 py-5">Taariikhda</th>
                <th className="px-8 py-5">Sharaxaad</th>
                <th className="px-8 py-5 text-right">Lacagta ($)</th>
                <th className="px-8 py-5 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {expenses.map(e => (
                <tr key={e.id} className="hover:bg-slate-50/50 transition-all group">
                  <td className="px-8 py-5 text-slate-500 font-medium">
                    {new Date(e.timestamp).toLocaleDateString()}
                  </td>
                  <td className="px-8 py-5 font-black text-slate-700">{e.description}</td>
                  <td className="px-8 py-5 text-right font-black text-rose-600 text-lg">${e.amount.toFixed(2)}</td>
                  <td className="px-8 py-5 text-center">
                    <button 
                      onClick={() => { if(window.confirm('Ma hubtaa?')) onDelete(e.id); }}
                      className="w-10 h-10 flex items-center justify-center rounded-xl bg-rose-50 text-rose-500 hover:bg-rose-500 hover:text-white transition-all mx-auto"
                    >
                      🗑️
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="py-24 text-center text-slate-300">
             <div className="text-6xl mb-4">💸</div>
             <p className="font-black uppercase tracking-widest text-slate-400">Ma jiraan kharashyo la qoray</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Expenses;
