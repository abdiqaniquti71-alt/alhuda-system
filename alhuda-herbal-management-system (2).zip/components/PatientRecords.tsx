
import React, { useState } from 'react';
import { PatientRecord } from '../types';

interface PatientProps {
  records: PatientRecord[];
  onAdd: (r: Omit<PatientRecord, 'id'>) => void;
  onDelete: (id: string) => void;
}

const PatientRecords: React.FC<PatientProps> = ({ records, onAdd, onDelete }) => {
  const [formData, setFormData] = useState({ name: '', phone: '', disease: '', medicine: '', date: new Date().toISOString().split('T')[0] });
  const [showForm, setShowForm] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd(formData);
    setFormData({ name: '', phone: '', disease: '', medicine: '', date: new Date().toISOString().split('T')[0] });
    setShowForm(false);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Diiwaanka Xanuunada (Patient Records)</h2>
          <p className="text-sm text-gray-500">History of consultations and herbal prescriptions</p>
        </div>
        <button 
          onClick={() => setShowForm(!showForm)}
          className="bg-indigo-600 text-white px-6 py-2.5 rounded-xl font-bold shadow-lg hover:bg-indigo-700 transition-all"
        >
          {showForm ? 'Close Form' : 'Diiwaangeli Bukaan (Add Patient)'}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white p-8 rounded-3xl border border-indigo-100 shadow-xl grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 animate-slide-down">
          <Input label="Magaca (Name)" value={formData.name} onChange={v => setFormData({...formData, name: v})} />
          <Input label="Talefanka (Phone)" value={formData.phone} onChange={v => setFormData({...formData, phone: v})} />
          <Input label="Xanuunka (Disease)" value={formData.disease} onChange={v => setFormData({...formData, disease: v})} />
          <Input label="Daawada (Medicine)" value={formData.medicine} onChange={v => setFormData({...formData, medicine: v})} />
          <Input label="Taariikhda (Date)" type="date" value={formData.date} onChange={v => setFormData({...formData, date: v})} />
          <button className="lg:col-span-5 bg-indigo-600 text-white py-3 rounded-xl font-bold mt-2 shadow-lg hover:bg-indigo-700 transition-all">
            Kaydi Diiwaanka (Save Record)
          </button>
        </form>
      )}

      <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
        {records.length > 0 ? (
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
              <tr>
                <th className="px-8 py-5">Taariikh</th>
                <th className="px-8 py-5">Bukaan (Patient)</th>
                <th className="px-8 py-5">Talefan</th>
                <th className="px-8 py-5">Xanuunka</th>
                <th className="px-8 py-5">Daawada</th>
                <th className="px-8 py-5 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50 text-sm">
              {records.map(r => (
                <tr key={r.id} className="hover:bg-slate-50 transition-all group">
                  <td className="px-8 py-4 text-slate-500">{r.date}</td>
                  <td className="px-8 py-4 font-bold text-slate-800">{r.name}</td>
                  <td className="px-8 py-4 text-slate-500">{r.phone}</td>
                  <td className="px-8 py-4 text-indigo-600 font-medium italic">{r.disease}</td>
                  <td className="px-8 py-4 text-emerald-600 font-semibold">{r.medicine}</td>
                  <td className="px-8 py-4 text-center">
                    <button 
                      onClick={() => onDelete(r.id)}
                      className="opacity-0 group-hover:opacity-100 p-2 rounded-xl text-rose-300 hover:text-rose-600 transition-all"
                    >
                      🗑️
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="py-24 text-center text-slate-300 italic">
            Diiwaanka waa maran yahay.
          </div>
        )}
      </div>
    </div>
  );
};

const Input = ({ label, type = 'text', value, onChange }: any) => (
  <div>
    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">{label}</label>
    <input 
      type={type}
      className="w-full bg-slate-50 border-none rounded-xl p-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      required
    />
  </div>
);

export default PatientRecords;
