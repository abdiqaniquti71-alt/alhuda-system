
export type UserRole = 'admin' | 'manager' | 'cashier';
export type PaymentMethod = 'EVC Plus' | 'e-Dahab' | 'Somnet' | 'Cash' | 'Card';

export interface User {
  id: string;
  username: string;
  role: UserRole;
}

export interface Account {
  id: string;
  username: string;
  password: string;
  role: UserRole;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  cost: number;
  stock: number;
  category: string;
  imageUrl?: string;
  salesCount: number;
  expiryDate?: string;
}

export interface Sale {
  id: string;
  productId: string;
  productName: string;
  quantity: number;
  totalPrice: number;
  paymentMethod: PaymentMethod;
  timestamp: string;
}

export interface Expense {
  id: string;
  description: string;
  amount: number;
  category: string;
  timestamp: string;
}

export interface PatientRecord {
  id: string;
  name: string;
  phone: string;
  disease: string;
  medicine: string;
  date: string;
}

export interface AppState {
  products: Product[];
  sales: Sale[];
  expenses: Expense[];
  patientRecords: PatientRecord[];
  currentUser: User | null;
  accounts: Account[];
}
